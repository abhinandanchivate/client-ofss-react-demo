package com.ofss.ecommerce.service;

import java.util.List;
import java.util.Optional;


import com.ofss.ecommerce.ProductRepository;
import com.ofss.ecommerce.model.Product;

@jakarta.enterprise.context.ApplicationScoped
public class ProductService {

    @jakarta.inject.Inject
    private ProductRepository productRepository;

    public Product addProduct(Product product) {
        return productRepository.save(product);
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Optional<Product> getProductById(Long id) {
        return productRepository.findById(id);
        		//.orElseThrow( new ProductNotFoundException("Product not found with ID: " + id));
    }

    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }
}
