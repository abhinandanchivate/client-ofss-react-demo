package com.ofss.ecommerce;

import java.util.List;
import java.util.Optional;


import com.ofss.ecommerce.model.Product;
import com.ofss.ecommerce.service.ProductService;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/products")
public class ProductResource {

    @jakarta.inject.Inject
    private ProductService productService;

//    @GET
//    @Produces(MediaType.APPLICATION_JSON)
//    public List<Product> getAllProducts() {
//        return productService.getAllProducts();
//    }
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllProducts() {
        if (productService == null) {
            return Response.serverError().entity("ProductService not initialized").build();
        }
        return Response.ok("data").build();
    }


    @GET
    @Path("/{id}")
    @Produces(MediaType.TEXT_PLAIN)
    public String getProductById(@PathParam("id") Long id) {
        if(productService!=null) {
        	return "hello";
        }
    	//return productService.getProductById(id);
		return "bye";
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addProduct(Product product) {
        Product createdProduct = productService.addProduct(product);
        return Response.status(Response.Status.CREATED).entity(createdProduct).build();
    }

    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteProduct(@PathParam("id") Long id) {
        productService.deleteProduct(id);
        return Response.noContent().build();
    }
}
